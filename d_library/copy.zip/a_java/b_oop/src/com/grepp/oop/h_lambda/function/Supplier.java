package com.grepp.oop.h_lambda.function;

@FunctionalInterface
public interface Supplier<T> {

    T get();

}
