package com.grepp.oop.g_inner;

public abstract class AnonymousAbstractClass {

    public abstract void print();

}
