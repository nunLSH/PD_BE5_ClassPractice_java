package com.grepp.oop.f_interface;

public interface Encrypt {
    void encrypt();
}
