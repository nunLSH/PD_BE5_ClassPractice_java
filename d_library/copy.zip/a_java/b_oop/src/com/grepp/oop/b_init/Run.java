package com.grepp.oop.b_init;

public class Run {

    public static void main(String[] args) {
        A_init init = new A_init("임서현BBB");
//        A_init.loadClass();
    }

}
