package com.grepp.oop.h_lambda.function;

@FunctionalInterface
public interface Consumer<T>{

    void accept(T t);

}
