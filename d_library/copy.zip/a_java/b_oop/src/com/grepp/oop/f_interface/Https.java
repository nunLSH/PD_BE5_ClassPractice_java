package com.grepp.oop.f_interface;

public interface Https extends Communicable, Encrypt{

}
