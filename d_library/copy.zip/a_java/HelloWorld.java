// 컴파일 : 소스코드를 컴퓨터가 읽을 수 있는 형태로 변환
// 주석 : 소스코드에 대한 설명, 컴파일러가 무시
// 주석 종류 : // (단일행 주석), /* */(다중행 주석), /** */(문서주석)

/*
	주석의 종류는
	단일행 주석
	다중행 주석
	문서주석이 있습니다.
*/

public class HelloWorld{
	public static void main(String[] args){		
		System.out.println("여러분 반가워요. Hello World!");
	}	
}