package com.grepp.exception.custom;

public class TimeOutRuntimeException extends CommonException{

    public TimeOutRuntimeException(String message) {
        super(message);
    }
}
