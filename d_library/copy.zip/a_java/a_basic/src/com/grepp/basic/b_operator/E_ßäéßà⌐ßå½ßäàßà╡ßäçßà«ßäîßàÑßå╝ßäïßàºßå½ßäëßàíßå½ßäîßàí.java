package com.grepp.basic.b_operator;

public class E_논리부정연산자 {

    public static void main(String[] args) {
        // NOTE BE01 논리부정연산자 : !
        // true >> false
        // false >> true
        System.out.println(!true);
        System.out.println(!false);
    }
}
