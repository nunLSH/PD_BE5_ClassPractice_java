package com.grepp.library.f_stream.a_optional.error;

public class NotFoundException extends RuntimeException{

    public NotFoundException(String message) {
        super(message);
    }
}
